from flask import Flask, render_template_string, request, Response, stream_with_context, url_for
import yt_dlp
import requests
import re
import unidecode
from urllib.parse import quote_plus # ĐÃ THÊM: Để mã hóa URL tìm kiếm an toàn

app = Flask(__name__)

# ==========================================
# PHẦN GIAO DIỆN (HTML + TAILWIND CSS) ĐÃ ĐƯỢC BỔ SUNG
# ==========================================
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PVQ Downloader - Tải Video Facebook</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700&display=swap');
        body { font-family: 'Inter', sans-serif; }
        .loader {
            border: 4px solid #f3f3f3; border-top: 4px solid #3b82f6; border-radius: 50%;
            width: 24px; height: 24px; animation: spin 1s linear infinite; display: none;
        }
        @keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
    </style>
</head>
<body class="bg-gradient-to-br from-gray-100 to-blue-50 min-h-screen flex flex-col justify-between">

    <div class="w-full bg-white shadow-sm py-4">
        <div class="container mx-auto px-4 flex justify-between items-center">
            <h1 class="text-2xl font-bold text-blue-600 tracking-tight">
                <i class="fab fa-facebook-square text-3xl mr-2"></i>PVQ Downloader
            </h1>
            <span class="text-sm text-gray-500 font-semibold">Admin: PhanVanQuang</span>
        </div>
    </div>

    <div class="container mx-auto px-4 flex-grow flex flex-col justify-center items-center py-10">
        
        <div class="w-full max-w-lg text-center mb-8">
            <h2 class="text-3xl font-extrabold text-gray-800">Công Cụ Tải Video Facebook Miễn Phí</h2>
            <p class="text-gray-500 mt-2">Tải video từ Facebook với chất lượng tốt nhất (HD, Full HD) chỉ với vài bước đơn giản.</p>
        </div>

        <div class="bg-white p-8 rounded-2xl shadow-xl w-full max-w-lg transition-all duration-300 hover:shadow-2xl">
            <h3 class="text-center text-gray-800 text-xl font-bold mb-6">Dán Link Video Facebook</h3>
            
            <form method="POST" onsubmit="document.getElementById('loading').style.display='inline-block'">
                <div class="relative">
                    <input type="text" name="url" placeholder="https://www.facebook.com/..." required
                        class="w-full pl-4 pr-12 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition">
                    <i class="fas fa-link absolute right-4 top-4 text-gray-400"></i>
                </div>
                
                <button type="submit" class="w-full mt-4 bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 rounded-lg shadow-lg transition duration-200 flex justify-center items-center gap-2">
                    <div id="loading" class="loader"></div>
                    <span>Lấy Link Tải</span>
                </button>
            </form>

            {% if error %}
            <div class="mt-4 p-3 bg-red-100 text-red-700 rounded-lg text-sm flex items-center">
                <i class="fas fa-exclamation-circle mr-2"></i> {{ error }}
            </div>
            {% endif %}
        </div>

        {% if video_data %}
        <div class="bg-white p-6 rounded-2xl shadow-xl w-full max-w-lg mt-8 border-t-4 border-green-500">
            <div class="flex items-start gap-4">
                <img src="{{ video_data.thumbnail }}" alt="Thumb" class="w-24 h-24 object-cover rounded-lg shadow-md">
                <div class="flex-1">
                    <h3 class="font-bold text-gray-800 text-lg line-clamp-2">{{ video_data.title }}</h3>
                    <p class="text-xs text-gray-500 mt-1">Thời lượng: {{ video_data.duration }}</p>
                </div>
            </div>

            <div class="mt-6">
                <h4 class="text-sm font-semibold text-gray-600 mb-3 uppercase tracking-wider">Chọn độ phân giải:</h4>
                <div class="space-y-2">
                    {% for fmt in video_data.formats %}
                    <a href="{{ url_for('download_proxy', url=fmt.url, filename=video_data.title_slug + '_' + fmt.resolution.replace(' ', '_') + '.mp4') }}" 
                       class="block w-full text-center py-2 px-4 border border-blue-600 text-blue-600 rounded hover:bg-blue-600 hover:text-white transition font-medium flex justify-between items-center group">
                        <span><i class="fas fa-video mr-2"></i> {{ fmt.resolution }}</span>
                        <span class="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded group-hover:bg-white group-hover:text-blue-600">Tải ngay <i class="fas fa-download ml-1"></i></span>
                    </a>
                    {% endfor %}
                </div>
            </div>
        </div>
        
        <div class="bg-white p-6 rounded-2xl shadow-xl w-full max-w-lg mt-4 border-t-4 border-yellow-500">
            <h4 class="text-lg font-bold text-gray-700 mb-4 flex items-center">
                <i class="fas fa-search text-yellow-600 mr-2"></i> Kiểm Tra Bản Sao / Bản Quyền
            </h4>
            
            <p class="text-sm font-semibold text-gray-700 mb-2">1. Tìm kiếm bằng Tiêu đề video:</p>
            <div class="grid grid-cols-3 gap-3 mb-4">
                <a href="{{ video_data.google_search_url }}" target="_blank"
                   class="flex items-center justify-center p-2 bg-red-500 hover:bg-red-600 text-white font-medium rounded transition">
                    <i class="fab fa-google mr-1"></i> Google (Text)
                </a>
                
                <a href="{{ video_data.youtube_search_url }}" target="_blank"
                   class="flex items-center justify-center p-2 bg-red-700 hover:bg-red-800 text-white font-medium rounded transition">
                    <i class="fab fa-youtube mr-1"></i> YouTube
                </a>
                
                <a href="{{ video_data.tiktok_search_url }}" target="_blank"
                   class="flex items-center justify-center p-2 bg-black hover:bg-gray-800 text-white font-medium rounded transition">
                    <i class="fab fa-tiktok mr-1"></i> TikTok
                </a>
            </div>

            <p class="text-sm font-semibold text-gray-700 mb-2 border-t pt-3">2. Tìm kiếm bằng Hình ảnh (Thumbnail):</p>
            <a href="{{ video_data.google_image_search_url }}" target="_blank"
               class="flex items-center justify-center p-3 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded transition">
                <i class="fas fa-image mr-2"></i> Tìm kiếm bằng Hình ảnh trên Google
            </a>
            <p class="text-xs text-gray-500 mt-2">Công cụ này sẽ sử dụng ảnh đại diện (thumbnail) của video để dò tìm các bản sao trên Internet.</p>

        </div>
        {% endif %}

        <div class="bg-white p-6 rounded-2xl shadow-xl w-full max-w-lg mt-8">
            <h3 class="text-xl font-bold text-gray-700 mb-4 border-b pb-2 flex items-center">
                <i class="fas fa-question-circle text-blue-600 mr-2"></i> Hướng Dẫn Sử Dụng Chi Tiết
            </h3>
            <ol class="space-y-4 text-left text-gray-700">
                <li class="flex items-start">
                    <span class="text-xl font-bold text-blue-600 mr-3">1.</span>
                    <div>
                        <span class="font-bold">Lấy Link Video:</span>
                        <p class="text-sm text-gray-600">Trên Facebook, tìm video bạn muốn tải. Nhấn vào biểu tượng <i class="fas fa-ellipsis-h mx-1"></i> (3 chấm) ở góc trên bên phải bài viết, sau đó chọn **Sao chép liên kết**.</p>
                    </div>
                </li>
                <li class="flex items-start">
                    <span class="text-xl font-bold text-blue-600 mr-3">2.</span>
                    <div>
                        <span class="font-bold">Dán và Xử Lý:</span>
                        <p class="text-sm text-gray-600">Dán link vừa sao chép vào ô nhập liệu ở trên và nhấn nút **Lấy Link Tải**.</p>
                    </div>
                </li>
                <li class="flex items-start">
                    <span class="text-xl font-bold text-blue-600 mr-3">3.</span>
                    <div>
                        <span class="font-bold">Chọn Chất Lượng Tải Xuống:</span>
                        <p class="text-sm text-gray-600">Trang web sẽ hiển thị các tùy chọn độ phân giải (ví dụ: 360p, 720p, 1080p,...). Hãy chọn độ phân giải bạn mong muốn.</p>
                    </div>
                </li>
                 <li class="flex items-start">
                    <span class="text-xl font-bold text-blue-600 mr-3">4.</span>
                    <div>
                        <span class="font-bold">Hoàn Tất Tải Về:</span>
                        <p class="text-sm text-gray-600">Nhấn nút **Tải ngay**. Video sẽ được tải trực tiếp về máy tính/điện thoại của bạn (Trình duyệt sẽ tự động lưu file).</p>
                    </div>
                </li>
            </ol>
            <p class="text-xs text-red-500 mt-4 pt-4 border-t border-gray-100"><i class="fas fa-shield-alt mr-1"></i> Lưu ý: Chỉ hoạt động với video công khai (Public). Nếu muốn tải 1080p, bạn cần cài đặt FFmpeg.</p>
        </div>
    </div>

    <footer class="w-full bg-gray-800 text-white py-6 mt-auto">
        <div class="container mx-auto text-center">
            <p class="font-bold text-lg">Phát triển bởi Admin PhanVanQuang</p>
            <p class="text-gray-400 text-sm mt-1">© 2024 PVQ Studio. All rights reserved.</p>
        </div>
    </footer>

</body>
</html>
"""

# ==========================================
# PHẦN BACKEND (LOGIC) - CẬP NHẬT LOGIC INDEX()
# ==========================================

def format_seconds(seconds):
    if not seconds: return "N/A"
    m, s = divmod(seconds, 60)
    h, m = divmod(m, 60)
    if h > 0:
        return f"{int(h)}:{int(m):02d}:{int(s):02d}"
    return f"{int(m):02d}:{int(s):02d}"

def slugify(text):
    import re
    text = unidecode.unidecode(text).lower()
    return re.sub(r'[\W_]+', '_', text)

def get_facebook_video_info(url):
    ydl_opts = {
        'quiet': True,
        'no_warnings': True,
        'format': 'bestvideo*+bestaudio/best', 
    }
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            
            formats_list = []
            seen_res = set() 
            
            for f in info.get('formats', []):
                if f.get('url') and f.get('height'):
                    if f.get('vcodec') != 'none':
                        resolution = f"{f.get('height')}p"
                        
                        if f.get('ext'):
                            resolution += f" ({f.get('ext')})"

                        if resolution not in seen_res:
                            formats_list.append({
                                'resolution': resolution,
                                'url': f['url']
                            })
                            seen_res.add(resolution)
            
            formats_list.sort(key=lambda x: int(x['resolution'].split('p')[0]) if x['resolution'].split('p')[0].isdigit() else 0, reverse=True)


            title = info.get('title', 'facebook_video')

            return {
                'title': title,
                'title_slug': slugify(title),
                'thumbnail': info.get('thumbnail'),
                'duration': format_seconds(info.get('duration')),
                'formats': formats_list
            }
    except Exception as e:
        print(f"Lỗi khi xử lý yt-dlp: {e}")
        return None

@app.route('/', methods=['GET', 'POST'])
def index():
    video_data = None
    error = None
    if request.method == 'POST':
        url = request.form.get('url')
        if url:
            data = get_facebook_video_info(url)
            if data and data['formats']:
                video_data = data
                
                # 1. TẠO URL TÌM KIẾM BẰNG VĂN BẢN
                search_query = data['title']
                video_data['google_search_url'] = f"https://www.google.com/search?q={quote_plus(search_query)}"
                video_data['youtube_search_url'] = f"https://www.youtube.com/results?search_query={quote_plus(search_query)}"
                video_data['tiktok_search_url'] = f"https://www.tiktok.com/search?q={quote_plus(search_query)}" 
                
                # 2. TẠO URL TÌM KIẾM BẰNG HÌNH ẢNH (MỚI)
                thumbnail_url = data['thumbnail']
                # Google Search by Image (Search by URL)
                video_data['google_image_search_url'] = f"https://www.google.com/searchbyimage?image_url={quote_plus(thumbnail_url)}"

            else:
                error = "Không tìm thấy video hoặc Link riêng tư. Vui lòng đảm bảo video Public và bạn đã cài đặt FFmpeg."
        else:
            error = "Vui lòng nhập đường dẫn!"
    
    return render_template_string(HTML_TEMPLATE, video_data=video_data, error=error)

@app.route('/download_proxy')
def download_proxy():
    video_url = request.args.get('url')
    filename = request.args.get('filename', 'facebook_video.mp4')
    
    if not video_url:
        return "URL video không hợp lệ", 400

    try:
        r = requests.get(video_url, stream=True)
        r.raise_for_status() 

        def generate():
            for chunk in r.iter_content(chunk_size=8192):
                if chunk:
                    yield chunk

        response = Response(stream_with_context(generate()), content_type=r.headers.get('content-type', 'video/mp4'))
        response.headers['Content-Disposition'] = f'attachment; filename="{filename}"'
        response.headers['Content-Length'] = r.headers.get('Content-Length')
        
        return response

    except requests.exceptions.RequestException as e:
        print(f"Lỗi Proxy Download: {e}")
        return "Không thể kết nối đến nguồn video. Có thể link đã hết hạn hoặc bị chặn.", 500

if __name__ == '__main__':
    app.run(debug=True, port=5000)